create view pg_stat_archiver
            (archived_count, last_archived_wal, last_archived_time, failed_count, last_failed_wal, last_failed_time,
             stats_reset) as
SELECT s.archived_count,
       s.last_archived_wal,
       s.last_archived_time,
       s.failed_count,
       s.last_failed_wal,
       s.last_failed_time,
       s.stats_reset
FROM pg_stat_get_archiver() s(archived_count, last_archived_wal, last_archived_time, failed_count, last_failed_wal,
                              last_failed_time, stats_reset);

alter table pg_stat_archiver
    owner to twaincards;

grant select on pg_stat_archiver to public;

